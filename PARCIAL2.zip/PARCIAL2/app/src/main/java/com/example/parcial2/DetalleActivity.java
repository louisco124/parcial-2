package com.example.parcial2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;

public class DetalleActivity extends AppCompatActivity {

    TextView txtNombre, txtStatus, txtSpecies, txtGender, txtOrigin, txtLocation;
    ImageView imgDetalle;
    Button btnCerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        txtNombre = findViewById(R.id.txtNombreDetalle);
        imgDetalle = findViewById(R.id.imgDetalle);
        btnCerrar = findViewById(R.id.btnCerrar);
        txtStatus = findViewById(R.id.txtStatus);
        txtSpecies = findViewById(R.id.txtSpecies);
        txtGender = findViewById(R.id.txtGender);
        txtOrigin = findViewById(R.id.txtOrigin);
        txtLocation = findViewById(R.id.txtLocation);

        // Recibe los datos del Intent
        String nombre = getIntent().getStringExtra("nombre");
        String imagen = getIntent().getStringExtra("imagen");
        String status = getIntent().getStringExtra("status");
        String species = getIntent().getStringExtra("species");
        String gender = getIntent().getStringExtra("gender");
        String origin = getIntent().getStringExtra("origin");
        String location = getIntent().getStringExtra("location");

        // Muestra los datos
        txtNombre.setText(nombre);
        Picasso.get().load(imagen).into(imgDetalle);
        txtStatus.setText(status);
        txtSpecies.setText("Species: " + species);
        txtGender.setText(gender);
        txtOrigin.setText("Origin: " + origin);
        txtLocation.setText("Location: " + location);

        // Lógica del botón Cerrar Sesión
        btnCerrar.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("datos", MODE_PRIVATE);
            prefs.edit().clear().apply(); // Limpia SharedPreferences
            startActivity(new Intent(this, MainActivity.class)); // Vuelve a MainActivity
            finish(); // Cierra DetalleActivity
        });
    }
}