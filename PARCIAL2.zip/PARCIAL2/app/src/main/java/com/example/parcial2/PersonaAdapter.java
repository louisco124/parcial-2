package com.example.parcial2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button; // Importa Button
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class PersonaAdapter extends RecyclerView.Adapter<PersonaAdapter.ViewHolder> {

    private ArrayList<Persona> lista;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Persona persona);
    }

    public PersonaAdapter(ArrayList<Persona> lista, OnItemClickListener listener) {
        this.lista = lista;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_persona, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Persona persona = lista.get(position);
        holder.nombre.setText(persona.getNombre());
        holder.status.setText(persona.getStatus());
        holder.species.setText(persona.getSpecies());
        Picasso.get().load(persona.getImagenUrl()).into(holder.imagen);

        holder.btnSeeMore.setOnClickListener(v -> listener.onItemClick(persona));
        holder.itemView.setOnClickListener(v -> listener.onItemClick(persona));
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imagen;
        TextView nombre;
        TextView status;
        TextView species;
        Button btnSeeMore;

        ViewHolder(View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imgPersona);
            nombre = itemView.findViewById(R.id.txtNombre);
            status = itemView.findViewById(R.id.txtStatus);
            species = itemView.findViewById(R.id.txtSpecies);
            btnSeeMore = itemView.findViewById(R.id.btnSeeMore);
        }
    }
}