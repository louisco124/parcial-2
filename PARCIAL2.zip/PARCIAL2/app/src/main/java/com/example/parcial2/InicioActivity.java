package com.example.parcial2;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class InicioActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    PersonaAdapter adapter;
    ArrayList<Persona> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        lista = new ArrayList<>();
        // Datos de los personajes
        lista.add(new Persona("Rick Sanchez", "https://rickandmortyapi.com/api/character/avatar/1.jpeg", "Alive", "Human", "Male", "Earth (C-137)", "Citadel of Ricks"));
        lista.add(new Persona("Morty Smith", "https://rickandmortyapi.com/api/character/avatar/2.jpeg", "Alive", "Human", "Male", "Earth (C-137)", "Citadel of Ricks"));
        lista.add(new Persona("Summer Smith", "https://rickandmortyapi.com/api/character/avatar/3.jpeg", "Alive", "Human", "Female", "Earth (C-137)", "Citadel of Ricks"));
        lista.add(new Persona("Beth Smith", "https://rickandmortyapi.com/api/character/avatar/4.jpeg", "Alive", "Human", "Female", "Earth (C-137)", "Earth (Replacement Dimension)"));
        lista.add(new Persona("Jerry Smith", "https://rickandmortyapi.com/api/character/avatar/5.jpeg", "Alive", "Human", "Male", "Earth (C-137)", "Earth (Replacement Dimension)"));


        adapter = new PersonaAdapter(lista, this::abrirDetalle);
        recyclerView.setAdapter(adapter);
    }

    private void abrirDetalle(Persona persona) {
        Intent intent = new Intent(this, DetalleActivity.class);
        intent.putExtra("nombre", persona.getNombre());
        intent.putExtra("imagen", persona.getImagenUrl());
        intent.putExtra("status", persona.getStatus());
        intent.putExtra("species", persona.getSpecies());
        intent.putExtra("gender", persona.getGender());
        intent.putExtra("origin", persona.getOrigin());
        intent.putExtra("location", persona.getLocation());
        startActivity(intent);
    }
}