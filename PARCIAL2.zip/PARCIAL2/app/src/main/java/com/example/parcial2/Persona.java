package com.example.parcial2;

public class Persona {
    private String nombre;
    private String imagenUrl;
    private String status;
    private String species;
    private String gender;
    private String origin;
    private String location;

    public Persona(String nombre, String imagenUrl, String status, String species, String gender, String origin, String location) {
        this.nombre = nombre;
        this.imagenUrl = imagenUrl;
        this.status = status;
        this.species = species;
        this.gender = gender;
        this.origin = origin;
        this.location = location;
    }

    public String getNombre() {
        return nombre;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public String getStatus() {
        return status;
    }

    public String getSpecies() {
        return species;
    }

    public String getGender() {
        return gender;
    }

    public String getOrigin() {
        return origin;
    }

    public String getLocation() {
        return location;
    }
}